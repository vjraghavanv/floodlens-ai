FloodLens AI - AWS Amplify manual deploy package
=================================================
This zip contains the PRODUCTION BUILD of the FloodLens AI SPA (demo mode:
bundled GeoJSON, no AWS backend required). To host it:

1. AWS Console -> Amplify -> "Deploy without Git" / "Host web app" -> Deploy.
2. Drag this ZIP (or its extracted folder) into the manual-deploy drop zone.
3. After it deploys, add ONE SPA redirect so refreshes on any tab work:
   Amplify app -> Hosting -> Rewrites and redirects -> Add rule:
     Source address:  </^[^.]+$|\.(?!(css|gif|ico|jpg|js|png|txt|svg|woff|woff2|ttf|map|json|geojson)$)([^.]+$)/>
     Target address:  /index.html
     Type:            200 (Rewrite)
4. Open the amplifyapp.com URL -> that's your live map link for the submission.

Runs fully client-side; no VITE_API_BASE needed for the demo. To point it at a
real AWS API later, rebuild with VITE_API_BASE set and redeploy.
